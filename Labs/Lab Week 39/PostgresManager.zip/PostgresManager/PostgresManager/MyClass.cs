﻿using System;
using Npgsql;
using System.Windows.Forms;

namespace PostgresManager
{
    public class PostGresCon
    {
        NpgsqlConnection connection = null;
        NpgsqlCommand returnedQuery = null;
        NpgsqlDataReader rawdata = null;

        public string ConnStr { get; set; }

        // Connect to a PostgreSQL database
        public void OpenConnection()
        {
            try
            {
                connection = new NpgsqlConnection(ConnStr);
                connection.Open();
            }
            catch (Exception info)
            {
                MessageBox.Show("Unable to open database." + info.ToString());
                throw;
            }
        }

        // Define a query returning a single row result set
        public void SetQuery(string query)
        {
            returnedQuery = new NpgsqlCommand(query, connection);

        }

        // Execute the query and get data
        public void ReadData()
        {
            try
            {
                rawdata = returnedQuery.ExecuteReader();
            }
            catch (Exception info)
            {
                MessageBox.Show("Please check if table exists." + info.ToString());
                throw;
            }
        }

        public void EditData()
        {
            throw new NotImplementedException();

        }

        public void InsertData()
        {
            throw new NotImplementedException();

        }

        public void PrintData()
        {
            // Printout rows
            while (rawdata.Read())
                Console.Write("{0}\t{1} \n", rawdata[0], rawdata[1]);
        }

        public void CloseConn()
        {
            connection.Close();
        }
    }
}
