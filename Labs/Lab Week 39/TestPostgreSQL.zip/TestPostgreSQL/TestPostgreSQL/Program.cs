﻿using PostgresManager;

class PostGresHandler
{
    static void Main(string[] args)
    {
        string postgresQuery = "SELECT id, name FROM employee;";

        PostGresCon postGresCon = new PostGresCon
        {
            ConnStr = "Server=127.0.0.1;User ID=username;" + "Password=Password;Database=postgres;"
        };

        postGresCon.OpenConnection();
        postGresCon.SetQuery(postgresQuery);
        postGresCon.ReadData();
        postGresCon.PrintData();
        string postgresQuery2 = "INSERT into employee  values(9, NEWNAME);";
        postGresCon.SetQuery(postgresQuery2);
        postGresCon.InsertData();
        postGresCon.PrintData();
        postGresCon.CloseConn();


    }


}


