﻿using System;

namespace TennisGame
{
    class TennisGame
    {
        static void Main(string[] args)
        {
            var input = "";

            // Begin game of Tennis
            Console.WriteLine("Begin Simulation of a Game of Tennis. \n");
            while (!(input.ToLower().Contains("stop")))
            {
                // SimilateTennisGame handles the game simulation activities. 
                // It returns users input indicating to "stop" simulation or continue.
                input = SimulateTennisGame.PlaySet();
                Console.Write("\n");

            }
            Console.WriteLine("End of Simulation. \n");
        }

    }


    class SimulateTennisGame
    {
        // This class handles the tennis game simulation

        public static string PlaySet()
        {
            //
            // Handles the specific game simulation activities.
            //
            var player1 = 0;
            var player2 = 0;

            var random = new Random();

            while (!((player1 > (player2 + 1)) && (player1 > 3)) && !((player2 > (player1 + 1)) && (player2 > 3)))
            {
                var point = random.Next(1, 3);

                switch (point)
                {
                    case 1:
                        player1 = Scoring_Singles.Give_Point(player1);
                        break;
                    case 2:
                        player2 = Scoring_Singles.Give_Point(player2);
                        break;
                }

                ShowScores.Player1(player1, player2);
                ShowScores.Player2(player1, player2);

            }

            ShowScores.FinalScores(player1, player2);
            Console.Write("To quit enter 'stop'. Otherwise to continue hit enter. ");
            return Console.ReadLine();

        }
    }

    class Scoring_Singles
    {
        /*
         This class assigns points to each player and reveals the winner.
         This class currently only handles a singles game of tennis
         */


        public static int Give_Point(int player)
        {
            return player = player + 1;
        }

        public static string FindWinner(int player1, int player2)
        {
            //
            // Check which player won, i.e., player1 or player2
            //
            if (player1 > player2)
            {
                return "Player 1";
            }
            else
            {
                return "Player 2";
            }

        }

    }



    class ShowScores
    {
        //
        // This class reveals the scores for each player using the tennis lingo
        //

        public static void Player1(int player1, int player2)
        {
            // Using the tennis lingo, show the score(s) for Player 1 only

            switch (player1)
            {
                case 0:
                    Console.Write("Player 1: Love");
                    break;
                case 1:
                    Console.Write("Player 1: Fifteen");
                    break;
                case 2:
                    Console.Write("Player 1: Thirty");
                    break;
                default:
                    if (player1 > player2)
                        Console.Write("Advantage Player 1");
                    else if (player2 > player1) { }
                    else if (player1 == 3 && player2 == 3) { Console.WriteLine("Now: Deuce\n"); }
                    else if (player1.Equals(player2)) { }
                    else
                        Console.Write("Player 1: Forty");
                    break;
            }

        }


        public static void Player2(int player1, int player2)
        {
            // Using the tennis lingo, show the score(s) for Player 2 only

            switch (player2)
            {
                case 0:
                    Console.WriteLine(" - Player 2: Love\n");
                    break;
                case 1:
                    Console.WriteLine(" - Player 2: Fifteen\n");
                    break;
                case 2:
                    Console.WriteLine(" - Player 2:  Thirty\n");
                    break;
                default:
                    if (player2 > player1)
                        Console.WriteLine(" - Advantage Player 2\n");
                    else if (player1 > player2) { Console.WriteLine(" \n"); }
                    else if (player1 == 3 && player2 == 3) { }
                    else if (player2.Equals(player1))
                        Console.WriteLine("Now: Deuce\n");
                    else
                        Console.WriteLine(" - Player 2: Forty\n");
                    break;
            }
        }

        public static void FinalScores(int pl1, int pl2)
        {
            // State Winner.
            Console.WriteLine("\n" + Scoring_Singles.FindWinner(pl1, pl2) + " WINS." + "\n");

        }
    }

}