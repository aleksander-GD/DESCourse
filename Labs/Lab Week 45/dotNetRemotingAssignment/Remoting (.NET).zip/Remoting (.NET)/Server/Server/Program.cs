using System;
using System.Linq;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp; //To import: Go to "References" in solution --> Right click --> Add reference --> Search for "System.Runtime.Remoting" and check it off.
using System.Text;



	class Program
	{
		static void Main(string[] args)
		{
			EchoServer();
		}

		static void EchoServer()
		{
			Console.WriteLine("Demo Server started...");

			//Create and register the channel
			TcpChannel tcpChannel = new TcpChannel(9998);
			ChannelServices.RegisterChannel(tcpChannel, false);

			//Register the Echo class as singleton
			Type echoType = Type.GetType("Echo");
			RemotingConfiguration.RegisterWellKnownServiceType(echoType, "Echo", WellKnownObjectMode.Singleton);

			//Register the PalindromeChecker as singleton
			Type palindromeCheckerType = Type.GetType("PalindromeChecker");
			RemotingConfiguration.RegisterWellKnownServiceType(palindromeCheckerType, "PalindromeChecker", WellKnownObjectMode.Singleton);

			System.Console.WriteLine("Press ENTER to quit");
			System.Console.ReadLine();

		}

	}

	public interface IEcho
	{
		string Send(String message);
	}

	public class Echo : MarshalByRefObject, IEcho
	{
		public string Send(String message)
		{
			Console.WriteLine("Client sent: " + message);
			return "Server recieved: '" + message + "'";
		}
	}

	public interface IPalindromeChecker
	{
		Boolean isPalindrome(string word);
	}

	public class PalindromeChecker : MarshalByRefObject, IPalindromeChecker
	{
		public Boolean isPalindrome(string word)
		{
			return word.Equals(ReverseString(word), StringComparison.InvariantCultureIgnoreCase);
		}

		private string ReverseString(string users_input)
		{
			var newstr = new StringBuilder();
			Stack s = new Stack();

			foreach (var c in users_input.ToArray())
			{
				s.Push(c);
			}


			while (s.Size() > 0)
			{
				newstr.Append(s.Pop());
			}

			return newstr.ToString();
		}
	}

	interface IStack
	{
		void Push(char c);
		char Pop();
		char Peek();
		int Size();
		bool IsEmpty();
	}

	class Stack : IStack
	{
		char[] chars;
		int top;

		public Stack()
		{
			chars = new char[1000];
			top = 0;
		}

		public bool IsEmpty()
		{
			return top == 0 ? true : false;
		}

		public char Peek()
		{
			return chars[top - 1];
		}

		public char Pop()
		{
			top--;
			return chars[top];
		}

		public void Push(char c)
		{
			chars[top] = c;
			top++;
		}

		public int Size()
		{
			return top;
		}
	}

