using System;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
//To import: Go to "References" in solution --> Right click --> Add reference --> Search for "System.Runtime.Remoting" and check it off.

class MyClient
{
	public static void Main()
	{
		//The URL for the server
		string echoUrl = "tcp://localhost:9998/Echo";
		string paldindromeUrl = "tcp://localhost:9998/PalindromeChecker";

		//Register the channel
		TcpChannel tcpChannel = new TcpChannel();
		ChannelServices.RegisterChannel(tcpChannel,false);

		//Get the Echo remote object
		Type echoType = typeof(IEcho);
		IEcho remoteEcho = (IEcho)Activator.GetObject(echoType, echoUrl);

		//Get the PaldindromeChecker remote object
		Type palindromeCheckerType = typeof(IPalindromeChecker);
		IPalindromeChecker remotePalindromeChecker = (IPalindromeChecker)Activator.GetObject(palindromeCheckerType, paldindromeUrl);
	   
		string input = "";
        Console.WriteLine("Write a message to the server and wait for a response. (Type 'QUIT' to exit)");

        while (input != "QUIT")
         {
            input = Console.ReadLine();
            Console.WriteLine(remoteEcho.Send(input));
            Boolean palindrome = remotePalindromeChecker.isPalindrome(input);
            Console.WriteLine("It is " + palindrome + " that the message was a palindrome.");
         }

    }
}